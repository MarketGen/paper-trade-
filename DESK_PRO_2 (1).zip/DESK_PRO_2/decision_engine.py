class DecisionEngine:
    def evaluate(self,pair):
        change=float(pair.get('priceChange',{}).get('h24',0) or 0)
        if change>15:return 'COPY'
        if change>3:return 'WATCH'
        return 'SKIP'
