class Backtester: pass
