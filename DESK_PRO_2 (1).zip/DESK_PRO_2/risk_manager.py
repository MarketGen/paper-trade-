class RiskManager:
    def allow(self,decision,pair):
        liq=float(pair.get('liquidity',{}).get('usd',0) or 0)
        return decision!='SKIP' and liq>10000
