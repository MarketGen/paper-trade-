import requests
class DexScreenerClient:
    URL="https://api.dexscreener.com/latest/dex/search?q=SOL"
    def get_pairs(self):
        try:
            return requests.get(self.URL,timeout=10).json().get('pairs',[])
        except Exception:
            return []
