# DESK PRO 2.0
Autonomous paper trading scaffold for Solana.
