class PaperTrader:
    def __init__(self,capital):
        self.cash=capital; self.actions=[]
    def process(self,decision,pair):
        self.actions.append((decision,pair.get('baseToken',{}).get('symbol','?')))
    def summary(self):
        return {'cash':self.cash,'actions':self.actions}
