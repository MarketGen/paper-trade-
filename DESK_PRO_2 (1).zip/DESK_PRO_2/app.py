from market_data import DexScreenerClient
from decision_engine import DecisionEngine
from risk_manager import RiskManager
from paper_trader import PaperTrader

scanner=DexScreenerClient()
engine=DecisionEngine()
risk=RiskManager()
trader=PaperTrader(1000)

if __name__=="__main__":
    pairs=scanner.get_pairs()
    for p in pairs[:10]:
        d=engine.evaluate(p)
        if risk.allow(d,p):
            trader.process(d,p)
    print(trader.summary())
